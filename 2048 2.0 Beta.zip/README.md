# 2048

Understand how to use vanilla JavaScript to build a fun classic. 2048 is a game where you move blocks around on a grid. When the same numbered blocks collide they merge and double in value. Merge a block to 2048 to win. A calming and mesmerizing game of strategy and patience.

This is a demo of how to use plain HTML and CSS with JavaScript logic to build games!